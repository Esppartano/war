module INF1636_WAR {
    requires java.desktop;
}
