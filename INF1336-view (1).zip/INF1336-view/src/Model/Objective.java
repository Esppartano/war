package Model;

interface Objective {
    public boolean isComplete(Player player);
    public String getDescription();
}